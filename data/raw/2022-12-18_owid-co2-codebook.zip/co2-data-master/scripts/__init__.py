from pathlib import Path

# Define path to output directory.
OUTPUT_DIR = Path(__file__).parent.parent
